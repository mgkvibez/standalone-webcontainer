// Unreachable in practice: the install must fail before this is ever evaluated.
module.exports = { package: "@corpus-broken/missing-edge", version: "1.0.0" };
