// This file must never reach the VFS.
