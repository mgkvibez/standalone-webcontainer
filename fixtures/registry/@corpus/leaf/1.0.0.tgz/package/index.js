// @corpus/leaf 1.0.0: the smallest thing that can be required.
module.exports = { package: "@corpus/leaf", version: "1.0.0", leaf: 1 };
