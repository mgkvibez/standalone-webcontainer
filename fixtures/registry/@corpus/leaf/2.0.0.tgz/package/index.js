// @corpus/leaf 2.0.0: same shape, different value, so a resolved tree can be told apart by behaviour.
module.exports = { package: "@corpus/leaf", version: "2.0.0", leaf: 2 };
