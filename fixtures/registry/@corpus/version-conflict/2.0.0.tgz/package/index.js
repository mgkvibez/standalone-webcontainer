const leaf = require("@corpus/leaf");
// A flat tree that hoisted leaf@1 over this package's leaf@2 prints 1 here instead of 2, which is the point.
module.exports = { package: "@corpus/version-conflict", version: "2.0.0", leafVersion: leaf.version, total: leaf.leaf + 20 };
