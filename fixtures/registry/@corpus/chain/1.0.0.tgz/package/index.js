const leaf = require("@corpus/leaf");
// Reads the dependency rather than re-exporting it: a tree that installs the edge but not its target fails here.
module.exports = { package: "@corpus/chain", version: "1.0.0", leafVersion: leaf.version, total: leaf.leaf + 10 };
