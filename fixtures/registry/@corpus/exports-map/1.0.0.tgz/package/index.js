module.exports = { entry: "decoy-index", file: "index.js", version: "1.0.0" };
