const chain = require("@corpus/chain");
module.exports = { package: "@corpus/deep", version: "1.0.0", chainTotal: chain.total, total: chain.total + 100 };
