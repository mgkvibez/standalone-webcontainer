module.exports = { package: "@corpus/bin", version: "1.0.0", bin: "corpus-bin" };
