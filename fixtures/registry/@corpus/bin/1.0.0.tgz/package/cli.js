#!/usr/bin/env node
// The shebang is part of the test: the loader has to strip it rather than hand it to a parser.
const args = process.argv.slice(2);
console.log(["corpus-bin", ...args].join(" ").trim());
