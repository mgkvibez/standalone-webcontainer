export const marker = "@corpus/esm";
export function greet(name) {
  return `hello ${name} from @corpus/esm`;
}
export default { marker: "@corpus/esm", version: "1.0.0" };
